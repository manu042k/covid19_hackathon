package com.eyantra.hospital.Adapters;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.eyantra.hospital.Models.ItemModel;
import com.eyantra.hospital.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class ItemsAdapter extends RecyclerView.Adapter<ItemsAdapter.MyViewHolder> {
    Context context;
    ArrayList<ItemModel> itemModels;
    private DatabaseReference mDatabase,hospitalref;

    public ItemsAdapter(Context context, ArrayList<ItemModel> items) {
        this.itemModels=items;
        this.context=context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_items_adapter, parent, false);

        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final ItemModel itemModel=itemModels.get(position);
        holder.order_name.setText("Order Name : "+itemModel.getOrder_name());
        holder.order_quantity.setText("Order Quantity : "+itemModel.getOrder_quantity());
        if (itemModel.getOrder_status().equals("0"))
        {
            holder.order_status.setImageResource(R.drawable.inactive);
        }
        else {
            holder.order_status.setImageResource(R.drawable.active);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Dialog dialog=new Dialog(context);
                dialog.setContentView(R.layout.custom);
                dialog.setTitle("Title...");
                final EditText update_item = (EditText) dialog.findViewById(R.id.update_item);
                final EditText update_quantity=(EditText) dialog.findViewById(R.id.update_quantity);
                final EditText update_status=(EditText) dialog.findViewById(R.id.update_status);
                final Button update_button=dialog.findViewById(R.id.update_button);
                update_item.setText(itemModel.getOrder_name());
                update_quantity.setText(itemModel.getOrder_quantity());
                update_status.setText(itemModel.getOrder_status());
                final ImageView delete=dialog.findViewById(R.id.delete_button);
                delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        deleteItem(itemModel.getOrder_id());
                        dialog.dismiss();
                        itemModels.clear();
                    }
                });
                update_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String item=update_item.getText().toString();
                        String quantity=update_quantity.getText().toString();
                        String status=update_status.getText().toString();
                        if (item.isEmpty()||quantity.isEmpty()||status.isEmpty())
                        {
                            update_item.setError("Field Required");

                            update_quantity.setError("Field Required");

                            update_status.setError("Field Required");
                        }
                        else {
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
                            String currentDateandTime = sdf.format(new Date());
                            ItemModel update = new ItemModel(itemModel.getOrder_id(), item, quantity, status, currentDateandTime);
                            update(itemModel.getOrder_id(), update);
                            dialog.dismiss();
                            itemModels.clear();
                        }
                    }
                });
                dialog.show();

            }
        });
    }

    private void deleteItem(String order_id)
    {
        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        mDatabase = FirebaseDatabase.getInstance().getReference("orders");
        mDatabase.child(user.getUid()).child(order_id).removeValue();


    }

    private void update(String order_id, ItemModel itemModel)
    {

        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        mDatabase = FirebaseDatabase.getInstance().getReference("orders");
        mDatabase.child(user.getUid()).child(order_id).setValue(itemModel);

    }


    @Override
    public int getItemCount() {
        return itemModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView order_name,order_quantity;
        ImageView order_status;
        public MyViewHolder(View itemView) {
            super(itemView);
            order_name=itemView.findViewById(R.id.adapter_order_name);
            order_quantity=itemView.findViewById(R.id.adapter_order_quantity);
            order_status=itemView.findViewById(R.id.adapter_order_status);

        }
    }


}
