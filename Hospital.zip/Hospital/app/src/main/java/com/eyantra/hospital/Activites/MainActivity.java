package com.eyantra.hospital.Activites;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.eyantra.hospital.Models.HospitalModel;
import com.eyantra.hospital.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class MainActivity extends AppCompatActivity {

    FirebaseAuth mAuth;
    EditText hospital_email,hospital_password,hospital_name,hospital_phone,hospital_address;
    Button register;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        hospital_email=findViewById(R.id.register_hospital_email);
        hospital_password=findViewById(R.id.register_hospital_password);
        hospital_name=findViewById(R.id.register_hospital_name);
        hospital_phone=findViewById(R.id.register_hospital_phone);
        hospital_address=findViewById(R.id.register_hospital_address);
        register=findViewById(R.id.register_hospital);

        mAuth=FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference("Hospital");
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(hospital_name.getText().toString()))
                {
                    hospital_name.setText("");
                    hospital_name.setError("Enter name");
                }
                if(!isValidMail(hospital_email.getText().toString()))
                {
                    hospital_email.setText("");
                    hospital_email.setError("Enter Correct Email");
                }
                else if(!isValidMobile(hospital_phone.getText().toString()))
                {
                    hospital_phone.setText("");
                    hospital_phone.setError("Enter Correct Email");
                }
                else if(TextUtils.isEmpty(hospital_address.getText().toString()))
                {
                    hospital_address.setText("");
                    hospital_address.setError("Enter address");
                }
                else
                {
                    hospitalregister();
                }
            }
        });


    }
    private boolean isValidMail(String email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }
    private boolean isValidMobile(String phone) {
        return android.util.Patterns.PHONE.matcher(phone).matches();
    }

    private void hospitalregister()
    {
        final String email=hospital_email.getText().toString();
        final String password=hospital_password.getText().toString();
        mAuth.createUserWithEmailAndPassword(email,password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                        {
                            Toast.makeText(getApplicationContext(),"Registered Hospital",Toast.LENGTH_SHORT).show();
                            addHospital(email);
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                });

    }

    private void addHospital(String email)
    {
        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String id=user.getUid();
        String name=hospital_name.getText().toString();
        String phone=hospital_phone.getText().toString();
        String address=hospital_address.getText().toString();

        HospitalModel hospitalModel=new HospitalModel(id,email,name,phone,address);
        mDatabase.child(id).setValue(hospitalModel);
        Intent intent=new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(MainActivity.this,LoginActivity.class));
        finish();
    }
}
