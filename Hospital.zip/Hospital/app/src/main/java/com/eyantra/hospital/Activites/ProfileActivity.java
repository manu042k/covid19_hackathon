package com.eyantra.hospital.Activites;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.eyantra.hospital.Models.HospitalModel;
import com.eyantra.hospital.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class ProfileActivity extends AppCompatActivity {

    EditText hospital_email,hospital_name,hospital_phone,hospital_address;
    Button update;
    private DatabaseReference mDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        hospital_email=findViewById(R.id.profile_hospital_email);

        hospital_name=findViewById(R.id.profile_hospital_name);
        hospital_phone=findViewById(R.id.profile_hospital_phone);
        hospital_address=findViewById(R.id.profile_hospital_address);
        update=findViewById(R.id.update_hospital);
        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        mDatabase = FirebaseDatabase.getInstance().getReference("Hospital");
        mDatabase.child(user.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    String hospital_name1= (String) dataSnapshot.child("hospital_name").getValue();

                    String hospital_email1= (String) dataSnapshot.child("hospital_email").getValue();

                    String hospital_phone1= (String) dataSnapshot.child("hospital_phone").getValue();

                    String hospital_address1= (String) dataSnapshot.child("hospital_address").getValue();

                    hospital_address.setText(hospital_address1);
                    hospital_name.setText(hospital_name1);
                    hospital_email.setText(hospital_email1);
                    hospital_phone.setText(hospital_phone1);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name=hospital_name.getText().toString();

                String phone=hospital_phone.getText().toString();

                String email=hospital_email.getText().toString();

                String address=hospital_address.getText().toString();
                HospitalModel hospitalModel=new HospitalModel(user.getUid(),email,name,phone,address);
                mDatabase.child(user.getUid()).setValue(hospitalModel);
                Toast.makeText(getApplicationContext(),"Updated",Toast.LENGTH_SHORT).show();
            }
        });

    }
}
