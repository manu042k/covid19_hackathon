package com.eyantra.hospital.Activites;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.eyantra.hospital.Adapters.ItemsAdapter;
import com.eyantra.hospital.Models.ItemModel;
import com.eyantra.hospital.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class ItemsActivity extends AppCompatActivity {

    private FirebaseAuth.AuthStateListener authListener;
    private FirebaseAuth auth;
    private DatabaseReference mDatabase,hospitalref;
    private DatabaseReference rootRef,demoRef;
    private RecyclerView recyclerView;
    EditText item,quantity;
    Button add;
    ArrayList<ItemModel> items=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);
        auth = FirebaseAuth.getInstance();
        item=findViewById(R.id.items_add_item);
        add=findViewById(R.id.items_add_button);
        quantity=findViewById(R.id.items_add_quantity);
        recyclerView=findViewById(R.id.item_list);
        mDatabase = FirebaseDatabase.getInstance().getReference("orders");
        hospitalref = FirebaseDatabase.getInstance().getReference("Hospital");


        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        authListener=new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user1=firebaseAuth.getCurrentUser();
                if (user1==null){
                    startActivity(new Intent(ItemsActivity.this, LoginActivity.class));
                }

            }
        };
        Toast.makeText(getApplicationContext(),user.getEmail(),Toast.LENGTH_SHORT).show();
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id=mDatabase.push().getKey();
                String items=item.getText().toString();
                String quan=quantity.getText().toString();
                if (items.isEmpty()|| quan.isEmpty())
                {
                    item.setError("Field Required");
                    quantity.setError("Field Required");
                }
                else {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
                    String currentDateandTime = sdf.format(new Date());
                    ItemModel itemModel = new ItemModel(id, items, quan, "1", currentDateandTime);
                    mDatabase.child(user.getUid()).child(id).setValue(itemModel);
                    Toast.makeText(getApplicationContext(), "Item Added", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(ItemsActivity.this, DashBoardActivity.class));
                }
            }
        });



    }


    @Override
    protected void onResume() {
        super.onResume();
        fetchData();
    }


    private void fetchData() {
        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        items.clear();
        mDatabase.child(user.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot childsnapshot : dataSnapshot.getChildren())
                {
                    String order_id= (String) childsnapshot.child("order_id").getValue();

                    String order_name= (String) childsnapshot.child("order_name").getValue();

                    String order_quantity= (String) childsnapshot.child("order_quantity").getValue();

                    String order_status=(String) childsnapshot.child("order_status").getValue();
                    String date= (String) childsnapshot.child("order_time").getValue();

                    ItemModel itemModel=new ItemModel(order_id,order_name,order_quantity,order_status,date);

                    items.add(itemModel);

                    showItemsList(items);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void showItemsList(ArrayList<ItemModel> items)
    {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(linearLayoutManager);
        ItemsAdapter adapter=new ItemsAdapter(ItemsActivity.this,items);
        recyclerView.setAdapter(adapter);


    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(ItemsActivity.this,DashBoardActivity.class));
    }
}
