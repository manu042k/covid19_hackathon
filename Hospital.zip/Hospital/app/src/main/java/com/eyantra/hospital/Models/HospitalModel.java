package com.eyantra.hospital.Models;

public class HospitalModel
{
    private String hospital_id;
    private String hospital_name;
    private String hospital_email;
    private String hospital_phone;
    private String hospital_address;

    public HospitalModel(String hospital_id, String hospital_email,String hospital_name,String hospital_phone,String hospital_address) {
        this.hospital_id = hospital_id;
        this.hospital_email = hospital_email;
        this.hospital_name=hospital_name;
        this.hospital_phone=hospital_phone;
        this.hospital_address=hospital_address;
    }

    public String getHospital_name() {
        return hospital_name;
    }

    public void setHospital_name(String hospital_name) {
        this.hospital_name = hospital_name;
    }

    public String getHospital_phone() {
        return hospital_phone;
    }

    public void setHospital_phone(String hospital_phone) {
        this.hospital_phone = hospital_phone;
    }

    public String getHospital_id() {
        return hospital_id;
    }

    public void setHospital_id(String hospital_id) {
        this.hospital_id = hospital_id;
    }

    public String getHospital_email() {
        return hospital_email;
    }

    public void setHospital_email(String hospital_email) {
        this.hospital_email = hospital_email;
    }

    public String getHospital_address() {
        return hospital_address;
    }

    public void setHospital_address(String hospital_address) {
        this.hospital_address = hospital_address;
    }
}
