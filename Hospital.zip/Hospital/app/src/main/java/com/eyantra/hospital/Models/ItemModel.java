package com.eyantra.hospital.Models;

public class ItemModel
{
    private String order_id;
    private String order_name;
    private String order_quantity;
    private String order_status;
    private String order_time;

    public ItemModel(String order_id, String order_name,String order_quantity,String order_status,String order_time) {
        this.order_id = order_id;
        this.order_name = order_name;
        this.order_quantity=order_quantity;
        this.order_status=order_status;
        this.order_time=order_time;
    }

    public String getOrder_quantity() {
        return order_quantity;
    }

    public void setOrder_quantity(String order_quantity) {
        this.order_quantity = order_quantity;
    }

    public String getOrder_status() {
        return order_status;
    }

    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }

    public String getOrder_time() {
        return order_time;
    }

    public void setOrder_time(String order_time) {
        this.order_time = order_time;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getOrder_name() {
        return order_name;
    }

    public void setOrder_name(String order_name) {
        this.order_name = order_name;
    }
}
